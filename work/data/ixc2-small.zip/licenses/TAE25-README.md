---
license: cdla-permissive-2.0
tags:
- total-atomization-energies
- quantum-chemistry
- computational-chemistry
- chemistry
- coupled-cluster
pretty_name: MSR-ACC/TAE25
---

# Microsoft Research - Accurate Chemistry Collection: Total Atomization Energies

## Description

The Microsoft Research Accurate Chemistry Collection (MSR-ACC) provides a collection of accurate coupled cluster labels for training machine learning functionals.
MSR-ACC/TAE25 comprising 73,040 total atomization energies at the CCSD(T)/CBS level obtained with the W1-F12 thermochemical protocol.
The dataset is constructed to exhaustively cover the chemical space of closed-shell, charge-neutral, covalently bound equilibrium molecular structures containing up to 5 non-hydrogen atoms drawn from elements up to argon and lacking significant multireference character.
The dataset generation is described in [Accurate Chemistry Collection: Coupled cluster atomization energies for broad chemical space
](https://arxiv.org/abs/2506.14492).

MSR-ACC/TAE25 opens the way for developing and evaluating generally applicable machine-learning, density functional theory, and semi-empirical methods, and has already been used for training the first exchange correlation functional to reach chemical accuracy for atomization energies in [Accurate and scalable exchange-correlation with deep learning](https://arxiv.org/abs/2506.14665).
In contrast to smaller or more specialized TAE databases, MSR-ACC/TAE25 provides a large and chemically diverse test set for identifying systematic errors and validating approximate electronic structure methods, for example, in describing bond energies across a wide range of challenging s- and p-block compounds.
The size, diversity, and accuracy of the dataset make it useful not only for developing deep-learning DFT methods, but also for training and validating models such as graph neural networks, critically testing their ability to generalize beyond the typical organic chemistry focus of datasets like GDB-9.
Finally, the dataset can be filtered to create highly specific benchmarks to answer practical questions, such as selecting the most accurate functional for a particular type of chemical system (e.g., phosphorus sulfide compounds).

## Schema

The molecules in this dataset are stored in QCSchema format, the columns *symbols*, *geometry*, *molecular_charge*, and *molecular_multiplicity* are sufficient to create the full QCSchema document.
Additionally, the *name* field provides the sum formula and the *atomic_numbers* column provides the nuclear charges of each atom.
The SHA1 hash of each QCSchema document is provided in the *sha1* column.
Finally, the following extra columns are provided:

- *atom-count:all* : Number of all atoms
- *atom-count:non-h* : Number of non-hydrogen atoms
- *graph:all* : Molecular graph including all atoms
- *graph:non-h* : Molecular graph including non-hydrogen atoms
- *singlet-triplet-gap-s0-t1@\** : Energy difference between s0 and t1 state at specified level of theory
- *tae:frac[(T)]@\** : Fraction of perturbative triples contribution to the total atomization energy
- *tae@\** : Total atomization energy at specified level of theory
- *tae[\*]@\** : Component of the total atomization energy at specified level of theory

The *tae@w1-f12* column provides the reference label with the highest accuracy compared to experiment.

## Usage

To evaluate on MSR-ACC/TAE25 the user needs to compute the total atomization energy of the molecule.
The total atomization energy for a molecule *M* with *n* atoms of type *A* is defined as

$$
\text{TAE} = n\times E(A) - E(M)
$$

The atoms *A* are expected to be in their ground state multiplicity.

For completeness we provide the ground state multiplicities of all atomic species in MSR-ACC/TAE25 here for reference:

- Hydrogen (H): doublet
- Lithium (Li): doublet
- Beryllium (Be): singlet
- Bor (B): doublet
- Carbon (C): triplet
- Nitrogen (N): quartet
- Oxygen (O): triplet
- Fluorine (F): doublet
- Sodium (Na): doublet
- Magnesium (Mg): singlet
- Aluminium (Al): doublet
- Silicon (Si): triplet
- Phosphorous (P): quartet
- Sulfur (S): triplet
- Chlorine (Cl): doublet

## Reference

The dataset was imported from its [Zenodo record](https://doi.org/10.5281/zenodo.17629321)

## License

> Community Data License Agreement - Permissive - Version 2.0
>
> This is the Community Data License Agreement - Permissive, Version 2.0 (the "agreement"). Data Provider(s) and Data Recipient(s) agree as follows:
>
> 1\. Provision of the Data
>
> 1.1. A Data Recipient may use, modify, and share the Data made available by Data Provider(s) under this agreement if that Data Recipient follows the terms of this agreement.
>
> 1.2. This agreement does not impose any restriction on a Data Recipient's use, modification, or sharing of any portions of the Data that are in the public domain or that may be used, modified, or shared under any other legal exception or limitation.
>
> 2\. Conditions for Sharing Data
>
> 2.1. A Data Recipient may share Data, with or without modifications, so long as the Data Recipient makes available the text of this agreement with the shared Data.
>
> 3\. No Restrictions on Results
>
> 3.1. This agreement does not impose any restriction or obligations with respect to the use, modification, or sharing of Results.
>
> 4\. No Warranty; Limitation of Liability
>
> 4.1. All Data Recipients receive the Data subject to the following terms:
>
> THE DATA IS PROVIDED ON AN "AS IS" BASIS, WITHOUT REPRESENTATIONS, WARRANTIES OR CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY WARRANTIES OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
>
> NO DATA PROVIDER SHALL HAVE ANY LIABILITY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING WITHOUT LIMITATION LOST PROFITS), HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE DATA OR RESULTS, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
>
> 5\. Definitions
>
> 5.1. "Data" means the material received by a Data Recipient under this agreement.
>
> 5.2. "Data Provider" means any person who is the source of Data provided under this agreement and in reliance on a Data Recipient's agreement to its terms.
>
> 5.3. "Data Recipient" means any person who receives Data directly or indirectly from a Data Provider and agrees to the terms of this agreement.
>
> 5.4. "Results" means any outcome obtained by computational analysis of Data, including for example machine learning models and models' insights.


## Citation

When using MSR-ACC/TAE25 in your research, please reference it including the version number as follows:

> This work uses the MSR-ACC/TAE25 dataset.

```
@misc{ehlert2025,
   title={Accurate Chemistry Collection: Coupled cluster atomization energies for broad chemical space},
   author={Ehlert, Sebastian and Hermann, Jan and Vogels, Thijs and Satorras, Victor Garcia and Lanius, Stephanie and Segler, Marwin and Giesbertz, Klaas JH and Kooi, Derk P and Takeda, Kenji and Huang, Chin-Wei and Luise, Giulia and van den Berg, Rianne and Gori-Giorgi, Paola and Karton, Amir},
   year={2025},
   eprint={2506.14492},
   archivePrefix={arXiv},
   primaryClass={physics.chem-ph},
   url={https://arxiv.org/abs/2506.14492},
}
```

## Dataset contact

- Amir Karton, <amir.karton@une.edu.au>
- Jan Hermann, <jan.hermann@microsoft.com>
- Sebastian Ehlert, <sehlert@microsoft.com>
